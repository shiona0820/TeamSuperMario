#pragma once

#include "../GameObject.h"
#include "../../Utility/StageData.h"


class nokonoko
{
};

